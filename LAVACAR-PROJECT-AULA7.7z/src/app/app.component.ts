import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './shared/components/layout/header/header.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';


/*A estrutura de um componente possui o decorator
@Component e arquivos separados para template e folha
de estilos CCS: */
@Component({
  selector: 'app-root',

  /*Array de Imports com os components*/
  imports: [RouterOutlet, //Injeção do componente de rotas do Angular
    HeaderComponent, FooterComponent],

  /*Template HTML*/
  templateUrl: './app.component.html',

  /*Folha de estilos CCS */
  styleUrl: './app.component.css'
})
export class AppComponent {
  /*Atualiza o titulo da aplicação raiz do Projeto Angular*/
  title = 'Projeto Lavacar';

}
